import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        qb: {
          bg: "#0b0d10",
          panel: "#12151a",
          panel2: "#171b21",
          border: "#232830",
          accent: "#5865f2",
          accent2: "#7289ff",
          text: "#e6e8eb",
          muted: "#8b93a1",
          green: "#3ba55d",
          yellow: "#faa61a",
          red: "#ed4245",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
