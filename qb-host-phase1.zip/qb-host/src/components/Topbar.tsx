"use client";

import { signOut, useSession } from "next-auth/react";

export function Topbar() {
  const { data: session } = useSession();
  const user = session?.user;

  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-qb-border">
      <div />
      <div className="flex items-center gap-4">
        <button className="text-qb-muted hover:text-qb-text" title="Notifications">🔔</button>
        <div className="flex items-center gap-2">
          {user?.image ? (
            <img src={user.image} alt="" className="w-8 h-8 rounded-full" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-qb-accent flex items-center justify-center text-white text-sm">
              {(user?.name ?? "U")[0]}
            </div>
          )}
          <span className="text-sm">{user?.name ?? "User"}</span>
        </div>
        <button onClick={() => signOut({ callbackUrl: "/" })} className="qb-btn-secondary text-sm">
          Logout
        </button>
      </div>
    </header>
  );
}
