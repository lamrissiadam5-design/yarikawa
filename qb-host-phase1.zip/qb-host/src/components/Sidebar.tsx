"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV = [
  { href: "/dashboard", label: "Overview", icon: "📊" },
  { href: "/dashboard/bots", label: "My Bots", icon: "🤖" },
  { href: "/dashboard/bots/create", label: "Create Bot", icon: "➕" },
  { href: "/dashboard/billing", label: "Billing", icon: "💳" },
  { href: "/dashboard/settings", label: "Settings", icon: "⚙️" },
  { href: "/dashboard/docs", label: "Documentation", icon: "📄" },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 border-r border-qb-border bg-qb-panel min-h-screen p-4 hidden md:block">
      <div className="flex items-center gap-2 font-bold text-lg px-2 mb-6">
        <span className="w-8 h-8 rounded-lg bg-qb-accent flex items-center justify-center text-white">Q</span>
        QB Host
      </div>
      <nav className="space-y-1">
        {NAV.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                active ? "bg-qb-accent text-white" : "text-qb-muted hover:bg-qb-panel2 hover:text-qb-text"
              }`}
            >
              <span>{item.icon}</span>
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
