import type { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import DiscordProvider from "next-auth/providers/discord";
import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/password";

// NextAuth config for QB Host.
// - Credentials provider: email + password against the User table (bcrypt hash).
// - Discord provider: real OAuth2 flow. On successful sign-in we upsert a
//   DiscordAccount row linked to the User so bot-token-holding features can
//   later use the stored Discord identity.
// - JWT session strategy: no NextAuth DB adapter is required, so our Prisma
//   schema doesn't need to match the adapter's exact shape. Sessions are
//   still server-verified, httpOnly, secure cookies (NextAuth default).
//
// SECURITY: DISCORD_CLIENT_SECRET and NEXTAUTH_SECRET must only ever be read
// here, server-side, via process.env. Never expose them in client code or
// NEXT_PUBLIC_* variables.

export const authOptions: AuthOptions = {
  session: { strategy: "jwt" },
  secret: process.env.NEXTAUTH_SECRET,
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Email",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email.toLowerCase().trim() },
        });

        if (!user || !user.passwordHash) return null;
        if (user.suspended) return null;

        const valid = await verifyPassword(credentials.password, user.passwordHash);
        if (!valid) return null;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          image: user.avatarUrl,
          role: user.role,
        } as any;
      },
    }),
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID as string,
      clientSecret: process.env.DISCORD_CLIENT_SECRET as string,
      authorization: { params: { scope: "identify email" } },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "discord" && profile) {
        const discordProfile = profile as {
          id: string;
          username: string;
          discriminator?: string;
          avatar?: string | null;
          email?: string | null;
        };

        // Find or create the local User, then upsert the linked DiscordAccount
        // with fresh OAuth tokens. Never store the Discord client secret here —
        // only the per-user access/refresh tokens issued by Discord.
        const existingDiscordAccount = await prisma.discordAccount.findUnique({
          where: { discordUserId: discordProfile.id },
          include: { user: true },
        });

        let localUser = existingDiscordAccount?.user;

        if (!localUser) {
          localUser = await prisma.user.create({
            data: {
              email: discordProfile.email ?? undefined,
              name: discordProfile.username,
              avatarUrl: discordProfile.avatar
                ? `https://cdn.discordapp.com/avatars/${discordProfile.id}/${discordProfile.avatar}.png`
                : null,
            },
          });
        }

        if (localUser.suspended) return false;

        await prisma.discordAccount.upsert({
          where: { discordUserId: discordProfile.id },
          create: {
            userId: localUser.id,
            discordUserId: discordProfile.id,
            username: discordProfile.username,
            discriminator: discordProfile.discriminator ?? null,
            avatar: discordProfile.avatar ?? null,
            accessToken: account.access_token as string,
            refreshToken: account.refresh_token as string,
            tokenExpiresAt: new Date((account.expires_at as number) * 1000),
          },
          update: {
            username: discordProfile.username,
            discriminator: discordProfile.discriminator ?? null,
            avatar: discordProfile.avatar ?? null,
            accessToken: account.access_token as string,
            refreshToken: account.refresh_token as string,
            tokenExpiresAt: new Date((account.expires_at as number) * 1000),
          },
        });

        // Stash the resolved local user id so the jwt callback can use it.
        (user as any).id = localUser.id;
        (user as any).role = localUser.role;
      }

      return true;
    },
    async jwt({ token, user }) {
      if (user) {
        token.uid = (user as any).id;
        token.role = (user as any).role ?? "USER";
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.uid as string;
        (session.user as any).role = token.role as string;
      }
      return session;
    },
  },
};
