import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="qb-card p-5">
      <p className="text-sm text-qb-muted">{label}</p>
      <p className="text-2xl font-semibold mt-1">{value}</p>
    </div>
  );
}

export default async function DashboardOverviewPage() {
  const session = await getServerSession(authOptions);
  const userId = (session!.user as any).id as string;

  // Real query against the Bot table — returns 0s honestly until the
  // Create Bot flow (next phase) lets users actually create bots.
  const [totalBots, runningBots, stoppedBots, storageAgg] = await Promise.all([
    prisma.bot.count({ where: { userId } }),
    prisma.bot.count({ where: { userId, status: "RUNNING" } }),
    prisma.bot.count({ where: { userId, status: { in: ["STOPPED", "CRASHED"] } } }),
    prisma.bot.aggregate({ where: { userId }, _sum: { storageUsedMb: true } }),
  ]);

  const storageUsedMb = storageAgg._sum.storageUsedMb ?? 0;

  return (
    <div>
      <h1 className="text-xl font-semibold mb-1">Overview</h1>
      <p className="text-qb-muted mb-6">Welcome back, {session!.user?.name}.</p>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard label="Total Bots" value={totalBots} />
        <StatCard label="Running" value={runningBots} />
        <StatCard label="Stopped" value={stoppedBots} />
        <StatCard label="Storage Used" value={`${storageUsedMb} MB`} />
        <StatCard label="CPU" value="—" />
        <StatCard label="RAM" value="—" />
      </div>

      {totalBots === 0 && (
        <div className="qb-card p-8 mt-8 text-center">
          <p className="text-qb-muted mb-4">You haven't created any bots yet.</p>
          <Link href="/dashboard/bots/create" className="qb-btn-primary">Create your first bot</Link>
        </div>
      )}

      <p className="text-xs text-qb-muted mt-8">
        CPU/RAM show "—" until the bot runner (next phase) reports live container
        metrics — this dashboard never fabricates numbers.
      </p>
    </div>
  );
}
