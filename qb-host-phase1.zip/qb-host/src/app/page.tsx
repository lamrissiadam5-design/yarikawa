import Link from "next/link";

const FEATURES = [
  { title: "Easy Deployment", desc: "Push your bot's files and hit Start. QB Host handles the rest." },
  { title: "Persistent Storage", desc: "Your bot's files, database, and config survive every restart." },
  { title: "Live Console", desc: "Real-time logs streamed straight from your running bot process." },
  { title: "Environment Variables", desc: "Store tokens and secrets encrypted, never exposed in logs." },
  { title: "Automatic Restart", desc: "If your bot crashes, QB Host brings it back automatically." },
  { title: "Bot Monitoring", desc: "Live CPU, RAM, storage, and uptime for every bot you run." },
  { title: "Secure Infrastructure", desc: "Each bot runs in an isolated container with strict limits." },
  { title: "Multiple Bots", desc: "Manage every bot you own from one clean dashboard." },
];

const PLANS = [
  { name: "Free", price: "$0", storage: "500 MB storage", bots: "1 bot", cta: "Get Started" },
  { name: "Premium", price: "$9.99/mo", storage: "5 GB storage", bots: "5 bots", cta: "Upgrade", highlight: true },
  { name: "Pro", price: "$29.99/mo", storage: "20 GB storage", bots: "20 bots", cta: "Upgrade" },
];

export default function LandingPage() {
  return (
    <main>
      <nav className="flex items-center justify-between px-6 md:px-12 py-5 border-b border-qb-border">
        <div className="flex items-center gap-2 font-bold text-lg">
          <span className="w-8 h-8 rounded-lg bg-qb-accent flex items-center justify-center text-white">Q</span>
          QB Host
        </div>
        <div className="flex items-center gap-3">
          <Link href="/login" className="qb-btn-secondary">Login</Link>
          <Link href="/register" className="qb-btn-primary">Get Started</Link>
        </div>
      </nav>

      <section className="px-6 md:px-12 py-24 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold leading-tight">
          Host Your Discord Bots.
          <br />
          <span className="text-qb-accent2">Simple. Fast. Reliable.</span>
        </h1>
        <p className="mt-6 text-qb-muted text-lg">
          QB Host gives your Discord bots isolated, persistent, always-on hosting —
          with live logs, environment variables, and automatic crash recovery, all
          from one clean dashboard.
        </p>
        <div className="mt-8 flex items-center justify-center gap-4">
          <Link href="/register" className="qb-btn-primary text-base px-6 py-3">Get Started</Link>
          <Link href="/dashboard" className="qb-btn-secondary text-base px-6 py-3">Dashboard</Link>
        </div>
      </section>

      <section className="px-6 md:px-12 py-16 border-t border-qb-border">
        <h2 className="text-2xl font-semibold text-center mb-10">Why QB Host?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
          {FEATURES.map((f) => (
            <div key={f.title} className="qb-card p-5">
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-qb-muted">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="px-6 md:px-12 py-16 border-t border-qb-border">
        <h2 className="text-2xl font-semibold text-center mb-10">Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {PLANS.map((p) => (
            <div
              key={p.name}
              className={`qb-card p-6 flex flex-col ${p.highlight ? "border-qb-accent ring-1 ring-qb-accent" : ""}`}
            >
              <h3 className="font-semibold text-lg">{p.name}</h3>
              <p className="text-3xl font-bold mt-2">{p.price}</p>
              <ul className="mt-4 text-sm text-qb-muted space-y-1 flex-1">
                <li>{p.storage}</li>
                <li>{p.bots}</li>
              </ul>
              <Link href="/register" className={p.highlight ? "qb-btn-primary mt-6 text-center" : "qb-btn-secondary mt-6 text-center"}>
                {p.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="px-6 md:px-12 py-8 border-t border-qb-border text-center text-sm text-qb-muted">
        © {new Date().getFullYear()} QB Host. Not affiliated with Discord Inc.
      </footer>
    </main>
  );
}
