import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "QB Host — Discord Bot Hosting",
  description: "Host your Discord bots. Simple. Fast. Reliable.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-qb-bg text-qb-text font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
