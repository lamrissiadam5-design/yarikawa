"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      setLoading(false);
      setError(data.error ?? "Something went wrong.");
      return;
    }

    // Auto-login right after registration.
    const signInRes = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);

    if (signInRes?.error) {
      router.push("/login");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="qb-card w-full max-w-sm p-8">
        <h1 className="text-xl font-semibold mb-1">Create your account</h1>
        <p className="text-sm text-qb-muted mb-6">Start hosting your Discord bots for free.</p>

        <button
          onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}
          className="w-full qb-btn-secondary mb-4"
        >
          Continue with Discord
        </button>

        <div className="flex items-center gap-3 my-4">
          <div className="h-px bg-qb-border flex-1" />
          <span className="text-xs text-qb-muted">or</span>
          <div className="h-px bg-qb-border flex-1" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            required
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="qb-input w-full"
          />
          <input
            type="email"
            required
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="qb-input w-full"
          />
          <input
            type="password"
            required
            minLength={8}
            placeholder="Password (min. 8 characters)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="qb-input w-full"
          />
          {error && <p className="text-sm text-qb-red">{error}</p>}
          <button type="submit" disabled={loading} className="qb-btn-primary w-full">
            {loading ? "Creating account..." : "Create Account"}
          </button>
        </form>

        <p className="text-sm text-qb-muted mt-6 text-center">
          Already have an account?{" "}
          <Link href="/login" className="text-qb-accent2">Log in</Link>
        </p>
      </div>
    </main>
  );
}
