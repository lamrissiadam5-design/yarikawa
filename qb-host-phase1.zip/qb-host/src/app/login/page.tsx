"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (res?.error) {
      setError("Invalid email or password.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="qb-card w-full max-w-sm p-8">
        <h1 className="text-xl font-semibold mb-1">Welcome back</h1>
        <p className="text-sm text-qb-muted mb-6">Log in to your QB Host dashboard.</p>

        <button
          onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}
          className="w-full qb-btn-secondary mb-4"
        >
          Continue with Discord
        </button>

        <div className="flex items-center gap-3 my-4">
          <div className="h-px bg-qb-border flex-1" />
          <span className="text-xs text-qb-muted">or</span>
          <div className="h-px bg-qb-border flex-1" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="email"
            required
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="qb-input w-full"
          />
          <input
            type="password"
            required
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="qb-input w-full"
          />
          {error && <p className="text-sm text-qb-red">{error}</p>}
          <button type="submit" disabled={loading} className="qb-btn-primary w-full">
            {loading ? "Logging in..." : "Log In"}
          </button>
        </form>

        <p className="text-sm text-qb-muted mt-6 text-center">
          Don't have an account?{" "}
          <Link href="/register" className="text-qb-accent2">Sign up</Link>
        </p>
      </div>
    </main>
  );
}
