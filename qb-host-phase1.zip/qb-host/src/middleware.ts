export { default } from "next-auth/middleware";

// Server-side route protection — this is enforced by NextAuth's middleware
// on every request to a matched path, not just by hiding UI elements.
// Unauthenticated requests are redirected to /login before any dashboard
// page or API route body ever executes.
export const config = {
  matcher: ["/dashboard/:path*", "/api/bots/:path*"],
};
