/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Server-only secrets (Discord client secret, encryption key, etc.) are read
  // via process.env on the server. Never prefix them with NEXT_PUBLIC_.
};

module.exports = nextConfig;
