import { PrismaClient, PlanTier } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.plan.upsert({
    where: { tier: PlanTier.FREE },
    update: {},
    create: { tier: PlanTier.FREE, name: "Free", storageMb: 500, maxBots: 1, priceCents: 0 },
  });
  await prisma.plan.upsert({
    where: { tier: PlanTier.PREMIUM },
    update: {},
    create: { tier: PlanTier.PREMIUM, name: "Premium", storageMb: 5120, maxBots: 5, priceCents: 999 },
  });
  await prisma.plan.upsert({
    where: { tier: PlanTier.PRO },
    update: {},
    create: { tier: PlanTier.PRO, name: "Pro", storageMb: 20480, maxBots: 20, priceCents: 2999 },
  });
  console.log("Seeded plans: Free / Premium / Pro");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
