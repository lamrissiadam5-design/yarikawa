# QB Host — Phase 1: Auth + Dashboard Shell

This is the foundation of QB Host, a Discord bot hosting platform. This phase
implements **real, working** authentication and the dashboard shell. Bot
creation, the file manager, the live console, the Docker-based bot runner,
and the admin panel are being built in the phases that follow.

## What's real in this phase

- Email/password registration and login (bcrypt-hashed passwords, never
  plaintext).
- Discord OAuth2 login — on first sign-in, a `DiscordAccount` row is created
  and linked to the user with real access/refresh tokens from Discord.
- Server-verified sessions (NextAuth JWT strategy, httpOnly secure cookies).
- Server-side route protection on `/dashboard/*` via middleware **and** a
  layout-level session check (defense in depth) — not just hidden buttons.
- A dashboard overview page that queries the real `Bot` table via Prisma.
  It correctly shows all zeros right now, because bot creation doesn't
  exist yet — nothing here is faked.

## Setup

1. **Install dependencies** (requires network access, which this sandbox
   doesn't have — run this on your own machine):
   ```bash
   npm install
   ```

2. **Start PostgreSQL.** Easiest via Docker:
   ```bash
   docker run --name qbhost-db -e POSTGRES_USER=qbhost -e POSTGRES_PASSWORD=changeme \
     -e POSTGRES_DB=qbhost -p 5432:5432 -d postgres:16
   ```

3. **Copy environment variables:**
   ```bash
   cp .env.example .env
   ```
   - Generate `NEXTAUTH_SECRET`: `openssl rand -base64 32`
   - Create a Discord application at https://discord.com/developers/applications,
     add redirect URI `http://localhost:3000/api/auth/callback/discord`, and
     paste the Client ID/Secret into `.env`.

4. **Run migrations and seed the plans table:**
   ```bash
   npx prisma migrate dev --name init
   npm run db:seed
   ```

5. **Start the dev server:**
   ```bash
   npm run dev
   ```
   Visit http://localhost:3000. You should be able to:
   - View the landing page
   - Register with email/password → land on `/dashboard`
   - Log out, log back in with the same credentials
   - Click "Continue with Discord" → real Discord OAuth consent screen →
     redirected back and logged in
   - Try visiting `/dashboard` while logged out → redirected to `/login`

## Project structure so far

```
qb-host/
├── prisma/
│   ├── schema.prisma      # Full data model (auth now; bots/files/logs used by later phases)
│   └── seed.ts            # Seeds Free/Premium/Pro plans
├── src/
│   ├── app/
│   │   ├── page.tsx               # Landing page
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   ├── dashboard/
│   │   │   ├── layout.tsx         # Sidebar + topbar + session guard
│   │   │   └── page.tsx           # Overview (real Prisma counts)
│   │   └── api/auth/
│   │       ├── [...nextauth]/route.ts
│   │       └── register/route.ts
│   ├── components/
│   │   ├── Sidebar.tsx
│   │   └── Topbar.tsx
│   ├── lib/
│   │   ├── auth.ts        # NextAuth config (Credentials + Discord)
│   │   ├── prisma.ts
│   │   └── password.ts
│   ├── middleware.ts       # Protects /dashboard/* and /api/bots/*
│   └── types/next-auth.d.ts
└── .env.example
```

## Coming in the next phases

- **Phase 2:** Create Bot flow + Bot detail page shell, Prisma-backed CRUD.
- **Phase 3:** File manager with persistent, path-traversal-safe storage
  under `/data/users/{userId}/bots/{botId}/`.
- **Phase 4:** Real bot runner — Docker container start/stop/restart via
  `dockerode`, WebSocket log streaming, crash detection + auto-restart.
- **Phase 5:** Environment variable manager (AES-256-GCM encrypted at rest),
  resource monitoring charts, admin panel, storage quota enforcement.
- **Phase 6:** Production Dockerfile, docker-compose.yml (app + Postgres +
  reverse proxy), and VPS deployment walkthrough.

Say "continue" / "next phase" and I'll build the next one on top of this.
